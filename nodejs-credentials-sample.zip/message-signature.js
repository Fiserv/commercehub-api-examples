const crypto = require("crypto");

const signMessage = (message, secret) => {
    const hmac = crypto.createHmac('sha256', secret);
    hmac.update(message);
    return hmac.digest('base64');
};

// Creates the headers required for the api call including message signature
const getHeaders = (apiKey, secret, payload) => {
  const clientRequestId = crypto.randomUUID();
  const timeStamp = new Date().getTime();
  const messageToSign = apiKey + clientRequestId + timeStamp + payload;

  const messageSignature = signMessage(messageToSign);

  return {
    "Content-Type": "application/json",
    "Client-Request-Id": clientRequestId,
    "Api-Key": apiKey,
    "Timestamp": timeStamp,
    "Auth-Token-Type": "HMAC",
    "Authorization": computedHmac
  };
}

// test for comparing message signing algorithm output

const postmanWithCryptoJSAlgorithmOutput = "nc4mCfLWfUH3TH+e/IzNRDcNQa0t5SmCYnWI3+comrg=";
console.log("postman CryptoJS reference output: " + postmanWithCryptoJSAlgorithmOutput);

const signatureAlgorithmOutput = signMessage("hello world", "12345");

console.log("NodeJS crypto module output: " + signatureAlgorithmOutput);

const isMatch = signatureAlgorithmOutput === postmanWithCryptoJSAlgorithmOutput;

if (isMatch) {
  console.log("success! signing algorithm is implemented correctly");
} else {
  console.log("there is a problem with the signing code!");
}

