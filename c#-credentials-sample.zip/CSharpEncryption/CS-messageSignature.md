```cs
using System;
using System.Text;
using System.Security.Cryptography;

namespace MessageSig;

class MessageSignature
{
    public static Dictionary<string, string> GetHeaders(string apiKey, string apiSecret, string payload)
    {
        // Generate additional headers
        Guid clientRequestId = Guid.NewGuid();
        long timeStamp = DateTimeOffset.Now.ToUnixTimeMilliseconds();
        string rawSignature = apiKey + clientRequestId + timeStamp + payload;

        // Instantiate the HMAC
        byte[] secretBytes = Encoding.UTF8.GetBytes(apiSecret);
        HMACSHA256 HMAC = new HMACSHA256(secretBytes);

        // Compute HMAC hash
        byte[] rawSignatureBytes = Encoding.UTF8.GetBytes(rawSignature);
        byte[] computedHmacBytes = HMAC.ComputeHash(rawSignatureBytes);
        string computedHmac = Convert.ToBase64String(computedHmacBytes);

        // Create headers (C# requires Content-Type to be added in the request object itself)
        return new Dictionary<string, string>() {
            { "Client-Request-Id", clientRequestId.ToString() },
            { "Api-Key", apiKey },
            { "Timestamp", timeStamp.ToString() },
            { "Auth-Token-Type", "HMAC" },
            { "Authorization", computedHmac }
        };
    }
}
```
