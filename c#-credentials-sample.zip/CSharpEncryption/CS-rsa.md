```cs
using System;
using System.Security.Cryptography;

namespace RSAEncryption;

class RSAEncrypt
{
    // A PaymentCard source is used as an example here, but other source types may be used as well
    public static EncryptedSource CreateEncryptedSource(PaymentCardSource cardSource, string publicKeyBase64, string keyId)
    {
        // Convert pubKey from base64 to raw bytes
        byte[] pubKey = Convert.FromBase64String(publicKeyBase64);

        // Instantiate RSA with pubKey (bytesRead variable is required for method)
        RSA rsa = RSA.Create();
        int bytesRead = 0;
        rsa.ImportSubjectPublicKeyInfo(pubKey, out bytesRead);

        // Encrypt data and encode into base64
        byte[] encryptedDataBytes = rsa.Encrypt(cardSource.card.BuildEncryptionBlockBytes(), RSAEncryptionPadding.OaepSHA256);
        string encryptedData = Convert.ToBase64String(encryptedDataBytes);
        rsa.Dispose();

        // Return payloadSource object, providing public key id, encryption block, and encryption block fields
        return new EncryptedSource("PaymentCard",
            new EncryptionData(keyId, "RSA", encryptedData, cardSource.card.BuildEncryptionBlockFields(), "MANUAL")
        );
    }
}

// Card Data model with helper methods to generate the encryptionBlock and encryptionBlockFields fields
public record CardData(string cardData, string nameOnCard, string expirationMonth, string expirationYear, string securityCode) {
    public byte[] BuildEncryptionBlockBytes()
    {
        string encryptionBlock = cardData + nameOnCard + expirationMonth + expirationYear + securityCode;

        byte[] encryptionBlockBytes = new byte[encryptionBlock.Length];
        for(int i = 0; i < encryptionBlock.Length; i++)
        {
            encryptionBlockBytes[i] = Convert.ToByte(encryptionBlock[i]);
        }

        return encryptionBlockBytes;
    }

    public string BuildEncryptionBlockFields()
    {
    return "card.cardData:" + cardData.Length +
        ",card.nameOnCard:" + nameOnCard.Length +
        ",card.expirationMonth:" + expirationMonth.Length +
        ",card.expirationYear:" + expirationYear.Length +
        ",card.securityCode:" + securityCode.Length;
    }
}

// Helper models
public record PaymentCardSource(String sourceType, CardData card) { }

public record EncryptionData(string keyId, string encryptionType, string encryptionBlock, string encryptionBlockFields, string encryptionTarget) { }

public record EncryptedSource(string sourceType, EncryptionData encryptionData) { }
```
