using RSAEncryption;
using AESEncryption;
using MessageSig;
using System.Text;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text.Json;

String pubKeyString = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5MZRqcOa/YN3Ckf7hJxMXNsMCeIP7Eb3QklbW5KVp9HBnfZTOjPc41aBCaRXvvOwQjQF57fFF4Hd/K9m7qpzMAxBfBa3t7tjhTBxNhWWsmeN9mvEQ2XzbzDZR2L0yfhpCXFsrJM66KIQHgYwRNFcwLUxg81CHaV4TQPJUO/HEW2y/Nwa1ipvE8mNtDBNe+pmIe+UdEjplZelwji7f0BJg/b0yGyVrPrKWbRN6Pcta6EcNaXum2ulANaRUYGRDqnXUlzT6n374WpHmMRVCG1aW0COvmTV3s8sltlIMTefMvg6EnxFL1XrAw/jbKzKIn6Ic740w3Iu0lfeMdkO9TXxQwIDAQAB";
String keyId = "6106e579-f773-4746-99bf-e30397738b3a";

Console.WriteLine("RSA encryption payload:");
RSAEncryption.PaymentCardSource cardData = new RSAEncryption.PaymentCardSource("PaymentCard", new RSAEncryption.CardData("4111111111111111", "John Smith", "01", "2034", "123"));
Console.WriteLine(JsonSerializer.Serialize(RSAEncrypt.CreateEncryptedSource(cardData, pubKeyString, keyId), new JsonSerializerOptions() { WriteIndented = true }));

Console.WriteLine();

Console.WriteLine("AES encryption payload:");
AESEncryption.UnencryptedSource unencryptedSource = new AESEncryption.UnencryptedSource("PaymentCard", new AESEncryption.CardData("4111111111111111", "John Smith", "01", "2034", "123"));
string source = JsonSerializer.Serialize(AESEncrypt.CreateEncryptedSource(unencryptedSource, pubKeyString, keyId), new JsonSerializerOptions() { WriteIndented = true });
Console.WriteLine(source);

MessageSignature.GetHeaders("a", "b", source);