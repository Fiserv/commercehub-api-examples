```cs
using System;
using System.Security.Cryptography;
using System.Text.Json;

namespace AESEncryption;

class AESEncrypt
{
    public static EncryptedSource CreateEncryptedSource(UnencryptedSource unencryptedSource, string publicKeyBase64, string keyId)
    {
        // Convert unencrypted source to Json bytes
        string unencryptedSourceString = JsonSerializer.Serialize(unencryptedSource);
        byte[] unencryptedSourceBytes = new byte[unencryptedSourceString.Length];
        for(int i = 0; i < unencryptedSourceString.Length; i++)
        {
            unencryptedSourceBytes[i] = Convert.ToByte(unencryptedSourceString[i]);
        }

        // Create the AES key and iv
        (byte[] aesKey, byte[] iv) = generateAESValues();

        // Encrypt payload with AES
        string fullEncryptedData = aesEncrypt(unencryptedSourceBytes, aesKey, iv);

        // Encrypt aesKey with RSA
        string encryptedAesKey = rsaEncrypt(aesKey, publicKeyBase64);

        // Create payloadSource object, providing public key id, encrypted key, encrypted data, and iv
        // A PaymentCard source is used as an example here, but other source types may be used as well
        return new EncryptedSource("PaymentCard",
            new EncryptionData(keyId, encryptedAesKey, fullEncryptedData, Convert.ToBase64String(iv), 128, "AES-GCM", "MANUAL")
        );
    }

    private static (byte[] aesKey, byte[] iv) generateAESValues()
    {
        RandomNumberGenerator random = RandomNumberGenerator.Create();
        byte[] aesKey = new byte[32];
        random.GetBytes(aesKey);
        byte[] iv = new byte[12];
        random.GetBytes(iv);
        random.Dispose();

        return (aesKey, iv);
    }

    private static string aesEncrypt(byte[] unencryptedSourceBytes, byte[] aesKey, byte[] iv)
    {
        // Instantiate AES-GCM with aesKey
        AesGcm aes = new AesGcm(aesKey, 16);

        // Encrypt data
        byte[] encryptedDataBytes = new byte[unencryptedSourceBytes.Length];
        byte[] tag = new byte[16];
        aes.Encrypt(iv, unencryptedSourceBytes, encryptedDataBytes, tag);
        aes.Dispose();

        // Append auth tag
        byte[] fullEncryptedDataBytes = new byte[encryptedDataBytes.Length + tag.Length];
        encryptedDataBytes.CopyTo(fullEncryptedDataBytes, 0);
        tag.CopyTo(fullEncryptedDataBytes, encryptedDataBytes.Length);
        return Convert.ToBase64String(fullEncryptedDataBytes);
    }

    private static string rsaEncrypt(byte[] unencryptedBytes, string publicKeyBase64)
    {
        // Convert pubKey from base64 to raw bytes
        byte[] pubKey = Convert.FromBase64String(publicKeyBase64);

        // Instantiate RSA with pubKey (bytesRead variable is required for method)
        RSA rsa = RSA.Create();
        int bytesRead = 0;
        rsa.ImportSubjectPublicKeyInfo(pubKey, out bytesRead);

        // Encrypt bytes and encode into base64
        byte[] encryptedDataBytes = rsa.Encrypt(unencryptedBytes, RSAEncryptionPadding.OaepSHA256);
        string encryptedData = Convert.ToBase64String(encryptedDataBytes);
        rsa.Dispose();

        return encryptedData;
    }
}

// Helper models (Only in this file for clarity)
public record CardData(String cardData, String nameOnCard, String expirationMonth, String expirationYear, String securityCode) { }

public record UnencryptedSource(String sourceType, CardData card) { }

public record EncryptionData(String keyId, String encryptedKey, String encryptionBlock, String aesIv, int aesTagLength, String encryptionType, String encryptionTarget) { }

public record EncryptedSource(String sourceType, EncryptionData encryptionData) { }
```
